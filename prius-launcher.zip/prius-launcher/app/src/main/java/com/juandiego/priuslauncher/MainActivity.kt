package com.juandiego.priuslauncher

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.setGeolocationEnabled(true)
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(
                    origin: String, callback: GeolocationPermissions.Callback
                ) = callback.invoke(origin, true, false)
            }
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        hideBars()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    // Como launcher, el botón Atrás no debe cerrar la pantalla de inicio.
    @Deprecated("Launcher: ignorar Atrás")
    override fun onBackPressed() {}

    inner class Bridge {

        // Paquetes conocidos para cada atajo; se usa el primero que esté instalado.
        private val shortcuts = mapOf(
            "youtube"   to listOf("com.google.android.youtube", "com.google.android.youtube.tv"),
            "ytmusic"   to listOf("com.google.android.apps.youtube.music"),
            "maps"      to listOf("com.google.android.apps.maps", "com.waze"),
            "radio"     to listOf("com.android.fmradio", "com.mediatek.fmradio", "com.syu.radio", "com.microntek.radio"),
            "btmusic"   to listOf("com.android.bluetooth", "com.syu.music", "com.microntek.btmusic"),
            "video"     to listOf("com.android.gallery3d", "com.mxtech.videoplayer.ad", "org.videolan.vlc"),
            "bluetooth" to listOf("com.syu.bt", "com.microntek.bluetooth", "com.android.settings")
        )

        @JavascriptInterface
        fun openApp(key: String) {
            for (pkg in shortcuts[key].orEmpty()) {
                if (launch(pkg)) return
            }
            if (key == "bluetooth") {
                startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } else if (key == "maps") {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }

        @JavascriptInterface
        fun openPackage(pkg: String) { launch(pkg) }

        @JavascriptInterface
        fun listApps(): String {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            packageManager.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
                .forEach {
                    arr.put(JSONObject()
                        .put("n", it.loadLabel(packageManager).toString())
                        .put("p", it.activityInfo.packageName))
                }
            return arr.toString()
        }

        @JavascriptInterface
        fun media(action: String) {
            val code = when (action) {
                "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                else   -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            }
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        }

        private fun launch(pkg: String): Boolean {
            val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            return true
        }
    }
}
