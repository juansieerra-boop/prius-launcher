plugins {
    id("com.android.application") version "8.5.2"
    id("org.jetbrains.kotlin.android") version "1.9.24"
}

android {
    namespace = "com.juandiego.priuslauncher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.juandiego.priuslauncher"
        minSdk = 21          // funciona desde Android 5 (muchas pantallas chinas traen Android 8-10)
        targetSdk = 28       // 28 evita restricciones nuevas en pantallas viejas
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
