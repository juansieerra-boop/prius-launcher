# Prius Launcher (Toyota Prius 2011)

Pantalla de inicio personalizada para tu pantalla Android del carro.

## Cómo instalarlo (la forma fácil)

1. Instala **Android Studio** (gratis) en tu computadora: https://developer.android.com/studio
2. Abre Android Studio → **Open** → selecciona esta carpeta `prius-launcher`.
3. Espera a que termine de sincronizar Gradle (la primera vez tarda unos minutos).
4. Menú **Build → Build APK(s)**. El archivo queda en `app/build/outputs/apk/`.
5. Pasa el APK a la pantalla del carro:
   - Por USB (memoria USB → abre el archivo en la pantalla e instala), o
   - Por ADB: `adb install app-release.apk`
6. En la pantalla: **Ajustes → Apps → Apps predeterminadas → Inicio** y elige **Prius Launcher**
   (o presiona el botón Home y marca "Siempre").

## Personalizar el diseño

Todo el diseño está en `app/src/main/assets/index.html`. Puedes cambiar colores,
tamaños y textos ahí sin tocar nada de Kotlin. Pídeme cambios y los hago.

## Notas

- El mini mapa y la velocidad usan GPS; el mapa necesita internet (hotspot del teléfono).
- Los atajos (Radio, Música BT, etc.) intentan varios nombres de app comunes en pantallas
  chinas. Si alguno no abre, dime la marca de tu pantalla y ajusto el paquete.
- "Luces encendidas" y datos del carro (CAN bus) no están incluidos: dependen del módulo
  de tu pantalla.
- Si algo sale mal, reinicia la pantalla o usa el botón RST para volver al launcher original.
